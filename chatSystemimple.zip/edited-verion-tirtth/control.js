const express = require('express');
const sqlite3 = require('sqlite3');
const hbs = require('express-hbs');
const bodyParser = require('body-parser');
const cookieSession = require("cookie-session");
const app = express();

const serv= require('http').Server(app);



app.engine('hbs',hbs.express4({
    partialsDir: __dirname + '/views/partials',
    defaultLayout: __dirname+'/views/layout/main.hbs'

}));

const allowedPages=[
    "/",
    "/new",
    "/forgot",
    "/home"
];

//function to check the authentication
function checkAuth(req,res,next){
    if (req.session && req.session.auth){
        console.log("here**");
        next();
    }
    else if (allowedPages.indexOf(req.url !== -1 )){
        console.log(req.url);
        next();
    }
    else{
        res.redirect("/notallowed");
    }
}



app.set('view engine','hbs');
app.set('views',__dirname+'/views');
let jsonParser = bodyParser.json();


// data bases
const db = new sqlite3.Database(__dirname+"database.db",function(err){
    if(!err){
        db.run(`CREATE TABLE IF NOT EXISTS users(
            username TEXT PRIMARY KEY,
            password TEXT
        )`);
        console.log("opened database");
    }
});


//function to create users
function newUser(res,stuff){
    
    db.run(`INSERT INTO users(username,password) VALUES(?,?)`,[stuff.user,stuff.pass]);
    let msg={
        text: 'New user created',
        location:"/"
    };
    // res.send(msg);
    row =  getall();
    res.send(JSON.stringify(msg));
    


}

//for checking if the user is in the database 
function checkSignIn(req,res,stuff){
    db.get(`SELECT * FROM users WHERE username = ?`,[stuff.user],function (err,row){
        if (!err){
            if (row){
                console.log(row);
                if (stuff.pass == row.password){
                    console.log("rendering the home page.....");
                    // res.render("homepage",{
                    //     title:"Home"
                    // });
                    req.session.auth = true;
                    req.session.user =stuff.user;
                    
                    let obj = {
                        location:"/home",
                        text: "ok"
                    }
                    res.send(JSON.stringify(obj));
                }
                else{ 
                    req.session.auth=false;
                    console.log("User and Pass not match");}
            }
            else{
                req.session.auth=false;
                console.log("NO data in database");
                
            }

        }
        else{console.log("Error loading database");}
    });
    
}
//function to get all the user in the database
function getall(){
    return db.get(`SELECT  * FROM users`);
    

}

app.use(cookieSession({
    name:"session",
    secret:"fooo"
}));
app.use(checkAuth);
app.use(express.static(__dirname+'/Public'));

app.get('/',function(req,res){
    
        console.log("request for homepage");
        console.log(req.session);
        console.log(req.session.auth); 
        if (!req.session.auth){
            res.render('longin',{
                title:'Welcome:'});

        }
        else{
            res.render("game",{
                title:"Game"
            });
        }
        
    
        


});


app.post('/',jsonParser, function(req,res){
    let stuff = req.body;
    console.log(stuff);
    
    checkSignIn(req,res,stuff);
   // checkUser();//for checking if the username and password matches
    
});

// req from clicking new to the website
app.get('/new',jsonParser,function(req,res,next){

    
    res.type('.html');
    res.render('register',{
        title:'Registration'
    });
 
});

//req from clicking forgot from the homepage
app.get("/forgot",function(req,res){
    res.type('.html');
    res.render('forgot',{title:"Recovery"});
});
app.get("/home",function(req,res){
    if(req.session.auth){ res.render("game",{
        title:"Game",
        
    });}
    else{
        res.render("longin",{
            title:"Welcome"
        });
    }

   
});
app.post('/new',jsonParser,function(req,res){
    let stuff = req.body;
    console.log(stuff);
    newUser(res,stuff);
    
    
});
app.post("/signout",jsonParser,function(req,res){
    req.session=null;
    let msg={
        location:"/"
    }
    res.send(JSON.stringify(msg));
});
app.post("/forgot",jsonParser,function(req,res){
    let stuff = req.body;
    db.get(`SELECT * FROM users WHERE username = ?`,[stuff.user],function (err,row){
        if (!err){
            if (row){
                let msg ={
                    password:"Your Password is " + row.password
                }   
                console.log("got user sending the password");
                res.send(JSON.stringify(msg));
            }
            else{
                let msg ={
                    password: "No user: " + stuff.user + " found!"              } 
                console.log("NO data in database");
                res.send(JSON.stringify(msg));
                
            }

        }
        else{
            let msg ={
                password: "No user: " + stuff.user + " found!"              } 
            console.log("NO data in database");
            res.send(JSON.stringify(msg)); 
    }
    });
    

});
app.get("/eg",jsonParser,function(req,res){
    console.log(req.session);
    res.send(res.session);
});


///////////////////////////game engine////////////////////////////////////
var socketList={};
var entity = function() {
    var self ={
        posx:250,
        posy:250,
        speedx:0,
        speedy:0,
        id:""
    }
    self.update = function(){
        self.updatePos();
    }
    self.updatePos= function(){
        self.posx += self.speedx;
        self.posy +=self.speedy;
    }
    self.getdist=function(pt){
        return Math.sqrt(Math.pow(self.posx-pt.posx,2)+Math.pow(self.posy-pt.posy,2));
    }
    return self;
}
var Player= function(id){
    var self = entity();
    self.id=id;
    // self.uername=;
    self.number=""+Math.floor(10*Math.random());
    self.goRight=false;
    self.goLeft=false;
    self.goUp=false;
    self.goDown=false;
    self.maxspeed=10; 
    self.attack=false;
    self.shootingangle=0;
    var entity_update = self.update;
    
    self.update= function(){
        self.updateSpeed();
        entity_update();
        if(self.attack){
            self.shoot(self.shootingangle);
            self.attack=false;
        }
    }
    self.shoot=function(angle){
        const bul = Bullet(self,angle);
        bul.posx=self.posx;
        bul.posy=self.posy;
        //console.log(bul.posx);
    }
    self.updateSpeed=function(){
        if(self.goDown)
            self.speedy =self.maxspeed;
        else if (self.goUp)
            self.speedy =-1*self.maxspeed;
        else
            self.speedy=0;
        if(self.goLeft)
            self.speedx =-1*self.maxspeed;
        else if(self.goRight)
            self.speedx =self.maxspeed;
        else
            self.speedx=0;
    };
    Player.list[id] = self;
    return self;
};
Player.list={};
Player.connect=function(socket){
    var player=Player(socket.id);
    socket.on('keyPressed',function(state){
        if(state.input == 'up')
            player.goUp=state.press;
        if(state.input=='right')
            player.goRight=state.press
        if(state.input == 'left')
            player.goLeft=state.press;
        if(state.input=='down')
            player.goDown=state.press;
        if(state.input=='attack')
            player.attack=state.press;
        if(state.input=='mouseAngle')
            player.shootingangle=state.press;

    });
}
Player.disconnect=function(socket){
    delete Player.list[socket.id];
}
Player.update= function(){
    var playerPack=[];
    for(var i in Player.list)
    {
        var player= Player.list[i];
        player.update();
        playerPack.push({
            x:player.posx,
            y:player.posy,
            number:player.number
        });
        
    }
    return playerPack;
}

var Bullet = function(parent,tangle){
    var self = entity();
    self.id= Math.random();
    self.speedx= Math.cos(tangle/180*Math.PI)*10;
    self.speedy = Math.sin(tangle/180*Math.PI)*10;
    console.log('tangle',tangle);
    console.log('parent',parent);
    self.time=0;
    self.parent=parent;
    self.dead =false;
    var entity_update = self.update;
    self.update = function(){
        if(self.time++ > 100)
            self.dead = true;
        entity_update();
        for(var i in Player.list){
            var p = Player.list[i];
            if(self.getdist(p)< 32 && self.parent.id !== p.id){
                self.dead=true;
            }
        }
    }
    Bullet.list[self.id]=self;
    return self;
};
Bullet.list={};

Bullet.update= function(){
    
    var bulletpack=[];
    
    for (var i in Bullet.list){
        var bullet =Bullet.list[i];
        bullet.update();
        if(bullet.dead)
        {
            delete Bullet.list[i];
        }
        bulletpack.push(
            {
                x:bullet.posx,
                y:bullet.posy
            }
        );
        
    }
    return bulletpack;
}

var io= require('socket.io')(serv,{});

io.sockets.on('connection',function(socket){

    socket.id = Math.random();
    socket.request;
    socketList[socket.id]=socket;
  

    console.log('socket connection'+" "+socket.request.headers.Cookie);
    Player.connect(socket);
    socket.on('disconnect',function(){
        delete socketList[socket.id];
        Player.disconnect(socket);
    });
    
    
});

setInterval(function(){
    var info ={
        player : Player.update(),
        bullet : Bullet.update()
    }
    
    for(var i in socketList){
        var socket=socketList[i];
        socket.emit('newposition',info);
        
    }
   
},1000/25);






const port = process.env.PORT || 8000;
// app.listen();
serv.listen(port,()=>console.log(`Listening on port ${port}!`))